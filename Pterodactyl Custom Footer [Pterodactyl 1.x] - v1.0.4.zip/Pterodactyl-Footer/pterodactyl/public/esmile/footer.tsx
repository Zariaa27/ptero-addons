export const dashfooter = "Pterodactyl | Power by Esmile Addons";
export const loginfooter = "Pterodactyl | Power by Esmile Addons";