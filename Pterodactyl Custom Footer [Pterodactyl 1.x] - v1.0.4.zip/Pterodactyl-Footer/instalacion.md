Sube la que esta en la carpeta pterodactyl en la carpeta /var/www/pterodactyl de su vps

Como poner el footer personalizado

Usa

nano /var/www/pterodactyl/public/esmile/footer.tsx

Busca
export const dashfooter = "Pterodactyl | Power by Esmile Addons";
export const loginfooter = "Pterodactyl | Power by Esmile Addons";

Reemplaza el texto "Pterodactyl | Power by Esmile Addons" por lo que quieres que salga ejemplo "My Panel"

Guarda y cierra el archivo

Comandos finales:

cd /var/www/pterodactyl
php artisan down
php artisan migrate --seed --force
yarn build:production
php artisan config:cache
php artisan view:cache
php artisan queue:restart
php artisan up


Una vez puesto si no te carga debes usar control + f5 de 3 a 4 veces para recargar el cache de la pagina y ya te cargue correctamente.