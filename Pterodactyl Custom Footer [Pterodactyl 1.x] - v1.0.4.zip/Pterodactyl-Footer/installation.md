Upload the one in the pterodactyl folder in the /var/www/pterodactyl folder of your vps

How to put the custom footer

Use

nano /var/www/pterodactyl/public/esmile/footer.tsx

Search
export const dashfooter = "Pterodactyl | Power by Esmile Addons";
export const loginfooter = "Pterodactyl | Power by Esmile Addons";

Replace the text "Pterodactyl | Power by Esmile Addons" with what you want to display as "My Panel" example

Save and close the file

Final commands:

cd /var/www/pterodactyl
php artisan down
php artisan migrate --seed --force
yarn build:production
php artisan config:cache
php artisan view:cache
php artisan queue:restart
php artisan up

Once set, if it doesn't load you should use control + f5 3 to 4 times to reload the cache of the page and it loads correctly.